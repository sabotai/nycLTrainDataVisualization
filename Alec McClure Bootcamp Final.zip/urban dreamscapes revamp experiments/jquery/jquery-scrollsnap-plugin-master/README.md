jquery-scrollsnap-plugin
========================

Javascript implementation of vertical scroll snapping.

Demo and documentation at http://benoit.pointet.info/stuff/jquery-scrollsnap-plugin/ .
